/*
 * PID.c
 *
 * Code generation for model "PID".
 *
 * Model version              : 1.3
 * Simulink Coder version : 9.0 (R2018b) 24-May-2018
 * C source code generated on : Tue Oct 29 23:37:38 2019
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "PID.h"
#include "PID_private.h"

/* Block signals (default storage) */
B_PID_T PID_B;

/* Continuous states */
X_PID_T PID_X;

/* Real-time model */
RT_MODEL_PID_T PID_M_;
RT_MODEL_PID_T *const PID_M = &PID_M_;

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 3;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  PID_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  PID_step();
  PID_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  PID_step();
  PID_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model step function */
void PID_step(void)
{
  real_T rtb_PProdOut;
  if (rtmIsMajorTimeStep(PID_M)) {
    /* set solver stop time */
    if (!(PID_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&PID_M->solverInfo, ((PID_M->Timing.clockTickH0 + 1)
        * PID_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&PID_M->solverInfo, ((PID_M->Timing.clockTick0 + 1) *
        PID_M->Timing.stepSize0 + PID_M->Timing.clockTickH0 *
        PID_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(PID_M)) {
    PID_M->Timing.t[0] = rtsiGetT(&PID_M->solverInfo);
  }

  /* Step: '<Root>/Step' */
  if (PID_M->Timing.t[0] < PID_P.Step_Time) {
    rtb_PProdOut = PID_P.Step_Y0;
  } else {
    rtb_PProdOut = PID_P.Step_YFinal;
  }

  /* End of Step: '<Root>/Step' */

  /* Sum: '<Root>/Sum' incorporates:
   *  Integrator: '<Root>/Integrator'
   */
  rtb_PProdOut -= PID_X.Integrator_CSTATE;

  /* Product: '<S45>/IProd Out' */
  PID_B.IProdOut = rtb_PProdOut * 0.0;

  /* Product: '<S65>/NProd Out' incorporates:
   *  Integrator: '<S34>/Filter'
   *  Product: '<S32>/DProd Out'
   *  Sum: '<S34>/SumD'
   */
  PID_B.NProdOut = (rtb_PProdOut * 0.0 - PID_X.Filter_CSTATE) * 0.0;

  /* Product: '<S72>/PProd Out' */
  rtb_PProdOut *= 0.0;

  /* Sum: '<S86>/Sum' incorporates:
   *  Integrator: '<S54>/Integrator'
   */
  PID_B.Sum = (rtb_PProdOut + PID_X.Integrator_CSTATE_k) + PID_B.NProdOut;
  if (rtmIsMajorTimeStep(PID_M)) {
    /* Matfile logging */
    rt_UpdateTXYLogVars(PID_M->rtwLogInfo, (PID_M->Timing.t));
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(PID_M)) {
    /* signal main to stop simulation */
    {                                  /* Sample time: [0.0s, 0.0s] */
      if ((rtmGetTFinal(PID_M)!=-1) &&
          !((rtmGetTFinal(PID_M)-(((PID_M->Timing.clockTick1+
               PID_M->Timing.clockTickH1* 4294967296.0)) * 0.2)) >
            (((PID_M->Timing.clockTick1+PID_M->Timing.clockTickH1* 4294967296.0))
             * 0.2) * (DBL_EPSILON))) {
        rtmSetErrorStatus(PID_M, "Simulation finished");
      }
    }

    rt_ertODEUpdateContinuousStates(&PID_M->solverInfo);

    /* Update absolute time for base rate */
    /* The "clockTick0" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick0"
     * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick0 and the high bits
     * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++PID_M->Timing.clockTick0)) {
      ++PID_M->Timing.clockTickH0;
    }

    PID_M->Timing.t[0] = rtsiGetSolverStopTime(&PID_M->solverInfo);

    {
      /* Update absolute timer for sample time: [0.2s, 0.0s] */
      /* The "clockTick1" counts the number of times the code of this task has
       * been executed. The resolution of this integer timer is 0.2, which is the step size
       * of the task. Size of "clockTick1" ensures timer will not overflow during the
       * application lifespan selected.
       * Timer of this task consists of two 32 bit unsigned integers.
       * The two integers represent the low bits Timing.clockTick1 and the high bits
       * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
       */
      PID_M->Timing.clockTick1++;
      if (!PID_M->Timing.clockTick1) {
        PID_M->Timing.clockTickH1++;
      }
    }
  }                                    /* end MajorTimeStep */
}

/* Derivatives for root system: '<Root>' */
void PID_derivatives(void)
{
  XDot_PID_T *_rtXdot;
  _rtXdot = ((XDot_PID_T *) PID_M->derivs);

  /* Derivatives for Integrator: '<Root>/Integrator' */
  _rtXdot->Integrator_CSTATE = PID_B.Sum;

  /* Derivatives for Integrator: '<S34>/Filter' */
  _rtXdot->Filter_CSTATE = PID_B.NProdOut;

  /* Derivatives for Integrator: '<S54>/Integrator' */
  _rtXdot->Integrator_CSTATE_k = PID_B.IProdOut;
}

/* Model initialize function */
void PID_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)PID_M, 0,
                sizeof(RT_MODEL_PID_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&PID_M->solverInfo, &PID_M->Timing.simTimeStep);
    rtsiSetTPtr(&PID_M->solverInfo, &rtmGetTPtr(PID_M));
    rtsiSetStepSizePtr(&PID_M->solverInfo, &PID_M->Timing.stepSize0);
    rtsiSetdXPtr(&PID_M->solverInfo, &PID_M->derivs);
    rtsiSetContStatesPtr(&PID_M->solverInfo, (real_T **) &PID_M->contStates);
    rtsiSetNumContStatesPtr(&PID_M->solverInfo, &PID_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&PID_M->solverInfo,
      &PID_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&PID_M->solverInfo,
      &PID_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&PID_M->solverInfo,
      &PID_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&PID_M->solverInfo, (&rtmGetErrorStatus(PID_M)));
    rtsiSetRTModelPtr(&PID_M->solverInfo, PID_M);
  }

  rtsiSetSimTimeStep(&PID_M->solverInfo, MAJOR_TIME_STEP);
  PID_M->intgData.y = PID_M->odeY;
  PID_M->intgData.f[0] = PID_M->odeF[0];
  PID_M->intgData.f[1] = PID_M->odeF[1];
  PID_M->intgData.f[2] = PID_M->odeF[2];
  PID_M->contStates = ((X_PID_T *) &PID_X);
  rtsiSetSolverData(&PID_M->solverInfo, (void *)&PID_M->intgData);
  rtsiSetSolverName(&PID_M->solverInfo,"ode3");
  rtmSetTPtr(PID_M, &PID_M->Timing.tArray[0]);
  rtmSetTFinal(PID_M, 10.0);
  PID_M->Timing.stepSize0 = 0.2;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    PID_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(PID_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(PID_M->rtwLogInfo, (NULL));
    rtliSetLogT(PID_M->rtwLogInfo, "tout");
    rtliSetLogX(PID_M->rtwLogInfo, "");
    rtliSetLogXFinal(PID_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(PID_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(PID_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(PID_M->rtwLogInfo, 0);
    rtliSetLogDecimation(PID_M->rtwLogInfo, 1);
    rtliSetLogY(PID_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(PID_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(PID_M->rtwLogInfo, (NULL));
  }

  /* block I/O */
  (void) memset(((void *) &PID_B), 0,
                sizeof(B_PID_T));

  /* states (continuous) */
  {
    (void) memset((void *)&PID_X, 0,
                  sizeof(X_PID_T));
  }

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(PID_M->rtwLogInfo, 0.0, rtmGetTFinal(PID_M),
    PID_M->Timing.stepSize0, (&rtmGetErrorStatus(PID_M)));

  /* InitializeConditions for Integrator: '<Root>/Integrator' */
  PID_X.Integrator_CSTATE = PID_P.Integrator_IC;

  /* InitializeConditions for Integrator: '<S34>/Filter' */
  PID_X.Filter_CSTATE = PID_P.PIDController_InitialConditionF;

  /* InitializeConditions for Integrator: '<S54>/Integrator' */
  PID_X.Integrator_CSTATE_k = PID_P.PIDController_InitialConditio_e;
}

/* Model terminate function */
void PID_terminate(void)
{
  /* (no terminate code required) */
}
