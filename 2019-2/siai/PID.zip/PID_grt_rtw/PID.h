/*
 * PID.h
 *
 * Code generation for model "PID".
 *
 * Model version              : 1.3
 * Simulink Coder version : 9.0 (R2018b) 24-May-2018
 * C source code generated on : Tue Oct 29 23:37:38 2019
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_PID_h_
#define RTW_HEADER_PID_h_
#include <float.h>
#include <string.h>
#include <stddef.h>
#ifndef PID_COMMON_INCLUDES_
# define PID_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#endif                                 /* PID_COMMON_INCLUDES_ */

#include "PID_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rt_nonfinite.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetContStateDisabled
# define rtmGetContStateDisabled(rtm)  ((rtm)->contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
# define rtmSetContStateDisabled(rtm, val) ((rtm)->contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
# define rtmGetContStates(rtm)         ((rtm)->contStates)
#endif

#ifndef rtmSetContStates
# define rtmSetContStates(rtm, val)    ((rtm)->contStates = (val))
#endif

#ifndef rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag
# define rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm) ((rtm)->CTOutputIncnstWithState)
#endif

#ifndef rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag
# define rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm, val) ((rtm)->CTOutputIncnstWithState = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
# define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
# define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetIntgData
# define rtmGetIntgData(rtm)           ((rtm)->intgData)
#endif

#ifndef rtmSetIntgData
# define rtmSetIntgData(rtm, val)      ((rtm)->intgData = (val))
#endif

#ifndef rtmGetOdeF
# define rtmGetOdeF(rtm)               ((rtm)->odeF)
#endif

#ifndef rtmSetOdeF
# define rtmSetOdeF(rtm, val)          ((rtm)->odeF = (val))
#endif

#ifndef rtmGetOdeY
# define rtmGetOdeY(rtm)               ((rtm)->odeY)
#endif

#ifndef rtmSetOdeY
# define rtmSetOdeY(rtm, val)          ((rtm)->odeY = (val))
#endif

#ifndef rtmGetPeriodicContStateIndices
# define rtmGetPeriodicContStateIndices(rtm) ((rtm)->periodicContStateIndices)
#endif

#ifndef rtmSetPeriodicContStateIndices
# define rtmSetPeriodicContStateIndices(rtm, val) ((rtm)->periodicContStateIndices = (val))
#endif

#ifndef rtmGetPeriodicContStateRanges
# define rtmGetPeriodicContStateRanges(rtm) ((rtm)->periodicContStateRanges)
#endif

#ifndef rtmSetPeriodicContStateRanges
# define rtmSetPeriodicContStateRanges(rtm, val) ((rtm)->periodicContStateRanges = (val))
#endif

#ifndef rtmGetRTWLogInfo
# define rtmGetRTWLogInfo(rtm)         ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetZCCacheNeedsReset
# define rtmGetZCCacheNeedsReset(rtm)  ((rtm)->zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
# define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->zCCacheNeedsReset = (val))
#endif

#ifndef rtmGetdX
# define rtmGetdX(rtm)                 ((rtm)->derivs)
#endif

#ifndef rtmSetdX
# define rtmSetdX(rtm, val)            ((rtm)->derivs = (val))
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               ((rtm)->Timing.t)
#endif

/* Block signals (default storage) */
typedef struct {
  real_T IProdOut;                     /* '<S45>/IProd Out' */
  real_T NProdOut;                     /* '<S65>/NProd Out' */
  real_T Sum;                          /* '<S86>/Sum' */
} B_PID_T;

/* Continuous states (default storage) */
typedef struct {
  real_T Integrator_CSTATE;            /* '<Root>/Integrator' */
  real_T Filter_CSTATE;                /* '<S34>/Filter' */
  real_T Integrator_CSTATE_k;          /* '<S54>/Integrator' */
} X_PID_T;

/* State derivatives (default storage) */
typedef struct {
  real_T Integrator_CSTATE;            /* '<Root>/Integrator' */
  real_T Filter_CSTATE;                /* '<S34>/Filter' */
  real_T Integrator_CSTATE_k;          /* '<S54>/Integrator' */
} XDot_PID_T;

/* State disabled  */
typedef struct {
  boolean_T Integrator_CSTATE;         /* '<Root>/Integrator' */
  boolean_T Filter_CSTATE;             /* '<S34>/Filter' */
  boolean_T Integrator_CSTATE_k;       /* '<S54>/Integrator' */
} XDis_PID_T;

#ifndef ODE3_INTG
#define ODE3_INTG

/* ODE3 Integration Data */
typedef struct {
  real_T *y;                           /* output */
  real_T *f[3];                        /* derivatives */
} ODE3_IntgData;

#endif

/* Parameters (default storage) */
struct P_PID_T_ {
  real_T PIDController_InitialConditionF;/* Mask Parameter: PIDController_InitialConditionF
                                          * Referenced by: '<S34>/Filter'
                                          */
  real_T PIDController_InitialConditio_e;/* Mask Parameter: PIDController_InitialConditio_e
                                          * Referenced by: '<S54>/Integrator'
                                          */
  real_T Integrator_IC;                /* Expression: 0
                                        * Referenced by: '<Root>/Integrator'
                                        */
  real_T Step_Time;                    /* Expression: 1
                                        * Referenced by: '<Root>/Step'
                                        */
  real_T Step_Y0;                      /* Expression: 0
                                        * Referenced by: '<Root>/Step'
                                        */
  real_T Step_YFinal;                  /* Expression: 1
                                        * Referenced by: '<Root>/Step'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_PID_T {
  const char_T *errorStatus;
  RTWLogInfo *rtwLogInfo;
  RTWSolverInfo solverInfo;
  X_PID_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  boolean_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeY[3];
  real_T odeF[3][3];
  ODE3_IntgData intgData;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block parameters (default storage) */
extern P_PID_T PID_P;

/* Block signals (default storage) */
extern B_PID_T PID_B;

/* Continuous states (default storage) */
extern X_PID_T PID_X;

/* Model entry point functions */
extern void PID_initialize(void);
extern void PID_step(void);
extern void PID_terminate(void);

/* Real-time Model object */
extern RT_MODEL_PID_T *const PID_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'PID'
 * '<S1>'   : 'PID/PID Controller'
 * '<S2>'   : 'PID/PID Controller/Anti-windup'
 * '<S3>'   : 'PID/PID Controller/D Gain'
 * '<S4>'   : 'PID/PID Controller/Filter'
 * '<S5>'   : 'PID/PID Controller/Filter ICs'
 * '<S6>'   : 'PID/PID Controller/I Gain'
 * '<S7>'   : 'PID/PID Controller/Ideal P Gain'
 * '<S8>'   : 'PID/PID Controller/Ideal P Gain Fdbk'
 * '<S9>'   : 'PID/PID Controller/Integrator'
 * '<S10>'  : 'PID/PID Controller/Integrator ICs'
 * '<S11>'  : 'PID/PID Controller/N Copy'
 * '<S12>'  : 'PID/PID Controller/N Gain'
 * '<S13>'  : 'PID/PID Controller/P Copy'
 * '<S14>'  : 'PID/PID Controller/Parallel P Gain'
 * '<S15>'  : 'PID/PID Controller/Reset Signal'
 * '<S16>'  : 'PID/PID Controller/Saturation'
 * '<S17>'  : 'PID/PID Controller/Saturation Fdbk'
 * '<S18>'  : 'PID/PID Controller/Sum'
 * '<S19>'  : 'PID/PID Controller/Sum Fdbk'
 * '<S20>'  : 'PID/PID Controller/Tracking Mode'
 * '<S21>'  : 'PID/PID Controller/Tracking Mode Sum'
 * '<S22>'  : 'PID/PID Controller/postSat Signal'
 * '<S23>'  : 'PID/PID Controller/preSat Signal'
 * '<S24>'  : 'PID/PID Controller/Anti-windup/Back Calculation'
 * '<S25>'  : 'PID/PID Controller/Anti-windup/Cont. Clamping Ideal'
 * '<S26>'  : 'PID/PID Controller/Anti-windup/Cont. Clamping Parallel'
 * '<S27>'  : 'PID/PID Controller/Anti-windup/Disabled'
 * '<S28>'  : 'PID/PID Controller/Anti-windup/Disc. Clamping Ideal'
 * '<S29>'  : 'PID/PID Controller/Anti-windup/Disc. Clamping Parallel'
 * '<S30>'  : 'PID/PID Controller/Anti-windup/Passthrough'
 * '<S31>'  : 'PID/PID Controller/D Gain/Disabled'
 * '<S32>'  : 'PID/PID Controller/D Gain/External Parameters'
 * '<S33>'  : 'PID/PID Controller/D Gain/Internal Parameters'
 * '<S34>'  : 'PID/PID Controller/Filter/Cont. Filter'
 * '<S35>'  : 'PID/PID Controller/Filter/Differentiator'
 * '<S36>'  : 'PID/PID Controller/Filter/Disabled'
 * '<S37>'  : 'PID/PID Controller/Filter/Disc. Backward Euler Filter'
 * '<S38>'  : 'PID/PID Controller/Filter/Disc. Forward Euler Filter'
 * '<S39>'  : 'PID/PID Controller/Filter/Disc. Trapezoidal Filter'
 * '<S40>'  : 'PID/PID Controller/Filter ICs/Disabled'
 * '<S41>'  : 'PID/PID Controller/Filter ICs/External IC'
 * '<S42>'  : 'PID/PID Controller/Filter ICs/Internal IC - Differentiator'
 * '<S43>'  : 'PID/PID Controller/Filter ICs/Internal IC - Filter'
 * '<S44>'  : 'PID/PID Controller/I Gain/Disabled'
 * '<S45>'  : 'PID/PID Controller/I Gain/External Parameters'
 * '<S46>'  : 'PID/PID Controller/I Gain/Internal Parameters'
 * '<S47>'  : 'PID/PID Controller/Ideal P Gain/External Parameters'
 * '<S48>'  : 'PID/PID Controller/Ideal P Gain/Internal Parameters'
 * '<S49>'  : 'PID/PID Controller/Ideal P Gain/Passthrough'
 * '<S50>'  : 'PID/PID Controller/Ideal P Gain Fdbk/Disabled'
 * '<S51>'  : 'PID/PID Controller/Ideal P Gain Fdbk/External Parameters'
 * '<S52>'  : 'PID/PID Controller/Ideal P Gain Fdbk/Internal Parameters'
 * '<S53>'  : 'PID/PID Controller/Ideal P Gain Fdbk/Passthrough'
 * '<S54>'  : 'PID/PID Controller/Integrator/Continuous'
 * '<S55>'  : 'PID/PID Controller/Integrator/Disabled'
 * '<S56>'  : 'PID/PID Controller/Integrator/Discrete'
 * '<S57>'  : 'PID/PID Controller/Integrator ICs/Disabled'
 * '<S58>'  : 'PID/PID Controller/Integrator ICs/External IC'
 * '<S59>'  : 'PID/PID Controller/Integrator ICs/Internal IC'
 * '<S60>'  : 'PID/PID Controller/N Copy/Disabled'
 * '<S61>'  : 'PID/PID Controller/N Copy/Disabled wSignal Specification'
 * '<S62>'  : 'PID/PID Controller/N Copy/External Parameters'
 * '<S63>'  : 'PID/PID Controller/N Copy/Internal Parameters'
 * '<S64>'  : 'PID/PID Controller/N Gain/Disabled'
 * '<S65>'  : 'PID/PID Controller/N Gain/External Parameters'
 * '<S66>'  : 'PID/PID Controller/N Gain/Internal Parameters'
 * '<S67>'  : 'PID/PID Controller/N Gain/Passthrough'
 * '<S68>'  : 'PID/PID Controller/P Copy/Disabled'
 * '<S69>'  : 'PID/PID Controller/P Copy/External Parameters Ideal'
 * '<S70>'  : 'PID/PID Controller/P Copy/Internal Parameters Ideal'
 * '<S71>'  : 'PID/PID Controller/Parallel P Gain/Disabled'
 * '<S72>'  : 'PID/PID Controller/Parallel P Gain/External Parameters'
 * '<S73>'  : 'PID/PID Controller/Parallel P Gain/Internal Parameters'
 * '<S74>'  : 'PID/PID Controller/Parallel P Gain/Passthrough'
 * '<S75>'  : 'PID/PID Controller/Reset Signal/Disabled'
 * '<S76>'  : 'PID/PID Controller/Reset Signal/External Reset'
 * '<S77>'  : 'PID/PID Controller/Saturation/Enabled'
 * '<S78>'  : 'PID/PID Controller/Saturation/Passthrough'
 * '<S79>'  : 'PID/PID Controller/Saturation Fdbk/Disabled'
 * '<S80>'  : 'PID/PID Controller/Saturation Fdbk/Enabled'
 * '<S81>'  : 'PID/PID Controller/Saturation Fdbk/Passthrough'
 * '<S82>'  : 'PID/PID Controller/Sum/Passthrough_I'
 * '<S83>'  : 'PID/PID Controller/Sum/Passthrough_P'
 * '<S84>'  : 'PID/PID Controller/Sum/Sum_PD'
 * '<S85>'  : 'PID/PID Controller/Sum/Sum_PI'
 * '<S86>'  : 'PID/PID Controller/Sum/Sum_PID'
 * '<S87>'  : 'PID/PID Controller/Sum Fdbk/Disabled'
 * '<S88>'  : 'PID/PID Controller/Sum Fdbk/Enabled'
 * '<S89>'  : 'PID/PID Controller/Sum Fdbk/Passthrough'
 * '<S90>'  : 'PID/PID Controller/Tracking Mode/Disabled'
 * '<S91>'  : 'PID/PID Controller/Tracking Mode/Enabled'
 * '<S92>'  : 'PID/PID Controller/Tracking Mode Sum/Passthrough'
 * '<S93>'  : 'PID/PID Controller/Tracking Mode Sum/Tracking Mode'
 * '<S94>'  : 'PID/PID Controller/postSat Signal/Feedback_Path'
 * '<S95>'  : 'PID/PID Controller/postSat Signal/Forward_Path'
 * '<S96>'  : 'PID/PID Controller/preSat Signal/Feedback_Path'
 * '<S97>'  : 'PID/PID Controller/preSat Signal/Forward_Path'
 */
#endif                                 /* RTW_HEADER_PID_h_ */
