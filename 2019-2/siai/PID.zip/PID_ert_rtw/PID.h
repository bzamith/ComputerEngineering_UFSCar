//
// File: PID.h
//
// Code generated for Simulink model 'PID'.
//
// Model version                  : 1.3
// Simulink Coder version         : 9.0 (R2018b) 24-May-2018
// C/C++ source code generated on : Tue Oct 29 23:38:35 2019
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives:
//    1. Execution efficiency
//    2. RAM efficiency
// Validation result: Not run
//
#ifndef RTW_HEADER_PID_h_
#define RTW_HEADER_PID_h_
#include <string.h>
#ifndef PID_COMMON_INCLUDES_
# define PID_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 // PID_COMMON_INCLUDES_

// Macros for accessing real-time model data structure
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               ((rtm)->Timing.t)
#endif

// Forward declaration for rtModel
typedef struct tag_RTM RT_MODEL;

// Block signals and states (default storage) for system '<Root>'
typedef struct {
  real_T NProdOut;                     // '<S65>/NProd Out'
  real_T Sum;                          // '<S86>/Sum'
  real_T IProdOut;                     // '<S45>/IProd Out'
} DW;

// Continuous states (default storage)
typedef struct {
  real_T Integrator_CSTATE;            // '<Root>/Integrator'
  real_T Filter_CSTATE;                // '<S34>/Filter'
  real_T Integrator_CSTATE_k;          // '<S54>/Integrator'
} X;

// State derivatives (default storage)
typedef struct {
  real_T Integrator_CSTATE;            // '<Root>/Integrator'
  real_T Filter_CSTATE;                // '<S34>/Filter'
  real_T Integrator_CSTATE_k;          // '<S54>/Integrator'
} XDot;

// State disabled
typedef struct {
  boolean_T Integrator_CSTATE;         // '<Root>/Integrator'
  boolean_T Filter_CSTATE;             // '<S34>/Filter'
  boolean_T Integrator_CSTATE_k;       // '<S54>/Integrator'
} XDis;

#ifndef ODE3_INTG
#define ODE3_INTG

// ODE3 Integration Data
typedef struct {
  real_T *y;                           // output
  real_T *f[3];                        // derivatives
} ODE3_IntgData;

#endif

// Real-time Model Data Structure
struct tag_RTM {
  const char_T *errorStatus;
  RTWSolverInfo solverInfo;
  X *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  boolean_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeY[3];
  real_T odeF[3][3];
  ODE3_IntgData intgData;

  //
  //  Sizes:
  //  The following substructure contains sizes information
  //  for many of the model attributes such as inputs, outputs,
  //  dwork, sample times, etc.

  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  //
  //  Timing:
  //  The following substructure contains information regarding
  //  the timing information for the model.

  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

// Class declaration for model PID
class PIDModelClass {
  // public data and function members
 public:
  // model initialize function
  void initialize();

  // model step function
  void step();

  // Constructor
  PIDModelClass();

  // Destructor
  ~PIDModelClass();

  // Real-Time Model get method
  RT_MODEL * getRTM();

  // private data and function members
 private:
  // Block signals and states
  DW rtDW;
  X rtX;                               // Block continuous states

  // Real-Time Model
  RT_MODEL rtM;

  // Continuous states update member function
  void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si );

  // Derivatives member function
  void PID_derivatives();
};

//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'PID'
//  '<S1>'   : 'PID/PID Controller'
//  '<S2>'   : 'PID/PID Controller/Anti-windup'
//  '<S3>'   : 'PID/PID Controller/D Gain'
//  '<S4>'   : 'PID/PID Controller/Filter'
//  '<S5>'   : 'PID/PID Controller/Filter ICs'
//  '<S6>'   : 'PID/PID Controller/I Gain'
//  '<S7>'   : 'PID/PID Controller/Ideal P Gain'
//  '<S8>'   : 'PID/PID Controller/Ideal P Gain Fdbk'
//  '<S9>'   : 'PID/PID Controller/Integrator'
//  '<S10>'  : 'PID/PID Controller/Integrator ICs'
//  '<S11>'  : 'PID/PID Controller/N Copy'
//  '<S12>'  : 'PID/PID Controller/N Gain'
//  '<S13>'  : 'PID/PID Controller/P Copy'
//  '<S14>'  : 'PID/PID Controller/Parallel P Gain'
//  '<S15>'  : 'PID/PID Controller/Reset Signal'
//  '<S16>'  : 'PID/PID Controller/Saturation'
//  '<S17>'  : 'PID/PID Controller/Saturation Fdbk'
//  '<S18>'  : 'PID/PID Controller/Sum'
//  '<S19>'  : 'PID/PID Controller/Sum Fdbk'
//  '<S20>'  : 'PID/PID Controller/Tracking Mode'
//  '<S21>'  : 'PID/PID Controller/Tracking Mode Sum'
//  '<S22>'  : 'PID/PID Controller/postSat Signal'
//  '<S23>'  : 'PID/PID Controller/preSat Signal'
//  '<S24>'  : 'PID/PID Controller/Anti-windup/Back Calculation'
//  '<S25>'  : 'PID/PID Controller/Anti-windup/Cont. Clamping Ideal'
//  '<S26>'  : 'PID/PID Controller/Anti-windup/Cont. Clamping Parallel'
//  '<S27>'  : 'PID/PID Controller/Anti-windup/Disabled'
//  '<S28>'  : 'PID/PID Controller/Anti-windup/Disc. Clamping Ideal'
//  '<S29>'  : 'PID/PID Controller/Anti-windup/Disc. Clamping Parallel'
//  '<S30>'  : 'PID/PID Controller/Anti-windup/Passthrough'
//  '<S31>'  : 'PID/PID Controller/D Gain/Disabled'
//  '<S32>'  : 'PID/PID Controller/D Gain/External Parameters'
//  '<S33>'  : 'PID/PID Controller/D Gain/Internal Parameters'
//  '<S34>'  : 'PID/PID Controller/Filter/Cont. Filter'
//  '<S35>'  : 'PID/PID Controller/Filter/Differentiator'
//  '<S36>'  : 'PID/PID Controller/Filter/Disabled'
//  '<S37>'  : 'PID/PID Controller/Filter/Disc. Backward Euler Filter'
//  '<S38>'  : 'PID/PID Controller/Filter/Disc. Forward Euler Filter'
//  '<S39>'  : 'PID/PID Controller/Filter/Disc. Trapezoidal Filter'
//  '<S40>'  : 'PID/PID Controller/Filter ICs/Disabled'
//  '<S41>'  : 'PID/PID Controller/Filter ICs/External IC'
//  '<S42>'  : 'PID/PID Controller/Filter ICs/Internal IC - Differentiator'
//  '<S43>'  : 'PID/PID Controller/Filter ICs/Internal IC - Filter'
//  '<S44>'  : 'PID/PID Controller/I Gain/Disabled'
//  '<S45>'  : 'PID/PID Controller/I Gain/External Parameters'
//  '<S46>'  : 'PID/PID Controller/I Gain/Internal Parameters'
//  '<S47>'  : 'PID/PID Controller/Ideal P Gain/External Parameters'
//  '<S48>'  : 'PID/PID Controller/Ideal P Gain/Internal Parameters'
//  '<S49>'  : 'PID/PID Controller/Ideal P Gain/Passthrough'
//  '<S50>'  : 'PID/PID Controller/Ideal P Gain Fdbk/Disabled'
//  '<S51>'  : 'PID/PID Controller/Ideal P Gain Fdbk/External Parameters'
//  '<S52>'  : 'PID/PID Controller/Ideal P Gain Fdbk/Internal Parameters'
//  '<S53>'  : 'PID/PID Controller/Ideal P Gain Fdbk/Passthrough'
//  '<S54>'  : 'PID/PID Controller/Integrator/Continuous'
//  '<S55>'  : 'PID/PID Controller/Integrator/Disabled'
//  '<S56>'  : 'PID/PID Controller/Integrator/Discrete'
//  '<S57>'  : 'PID/PID Controller/Integrator ICs/Disabled'
//  '<S58>'  : 'PID/PID Controller/Integrator ICs/External IC'
//  '<S59>'  : 'PID/PID Controller/Integrator ICs/Internal IC'
//  '<S60>'  : 'PID/PID Controller/N Copy/Disabled'
//  '<S61>'  : 'PID/PID Controller/N Copy/Disabled wSignal Specification'
//  '<S62>'  : 'PID/PID Controller/N Copy/External Parameters'
//  '<S63>'  : 'PID/PID Controller/N Copy/Internal Parameters'
//  '<S64>'  : 'PID/PID Controller/N Gain/Disabled'
//  '<S65>'  : 'PID/PID Controller/N Gain/External Parameters'
//  '<S66>'  : 'PID/PID Controller/N Gain/Internal Parameters'
//  '<S67>'  : 'PID/PID Controller/N Gain/Passthrough'
//  '<S68>'  : 'PID/PID Controller/P Copy/Disabled'
//  '<S69>'  : 'PID/PID Controller/P Copy/External Parameters Ideal'
//  '<S70>'  : 'PID/PID Controller/P Copy/Internal Parameters Ideal'
//  '<S71>'  : 'PID/PID Controller/Parallel P Gain/Disabled'
//  '<S72>'  : 'PID/PID Controller/Parallel P Gain/External Parameters'
//  '<S73>'  : 'PID/PID Controller/Parallel P Gain/Internal Parameters'
//  '<S74>'  : 'PID/PID Controller/Parallel P Gain/Passthrough'
//  '<S75>'  : 'PID/PID Controller/Reset Signal/Disabled'
//  '<S76>'  : 'PID/PID Controller/Reset Signal/External Reset'
//  '<S77>'  : 'PID/PID Controller/Saturation/Enabled'
//  '<S78>'  : 'PID/PID Controller/Saturation/Passthrough'
//  '<S79>'  : 'PID/PID Controller/Saturation Fdbk/Disabled'
//  '<S80>'  : 'PID/PID Controller/Saturation Fdbk/Enabled'
//  '<S81>'  : 'PID/PID Controller/Saturation Fdbk/Passthrough'
//  '<S82>'  : 'PID/PID Controller/Sum/Passthrough_I'
//  '<S83>'  : 'PID/PID Controller/Sum/Passthrough_P'
//  '<S84>'  : 'PID/PID Controller/Sum/Sum_PD'
//  '<S85>'  : 'PID/PID Controller/Sum/Sum_PI'
//  '<S86>'  : 'PID/PID Controller/Sum/Sum_PID'
//  '<S87>'  : 'PID/PID Controller/Sum Fdbk/Disabled'
//  '<S88>'  : 'PID/PID Controller/Sum Fdbk/Enabled'
//  '<S89>'  : 'PID/PID Controller/Sum Fdbk/Passthrough'
//  '<S90>'  : 'PID/PID Controller/Tracking Mode/Disabled'
//  '<S91>'  : 'PID/PID Controller/Tracking Mode/Enabled'
//  '<S92>'  : 'PID/PID Controller/Tracking Mode Sum/Passthrough'
//  '<S93>'  : 'PID/PID Controller/Tracking Mode Sum/Tracking Mode'
//  '<S94>'  : 'PID/PID Controller/postSat Signal/Feedback_Path'
//  '<S95>'  : 'PID/PID Controller/postSat Signal/Forward_Path'
//  '<S96>'  : 'PID/PID Controller/preSat Signal/Feedback_Path'
//  '<S97>'  : 'PID/PID Controller/preSat Signal/Forward_Path'

#endif                                 // RTW_HEADER_PID_h_

//
// File trailer for generated code.
//
// [EOF]
//
