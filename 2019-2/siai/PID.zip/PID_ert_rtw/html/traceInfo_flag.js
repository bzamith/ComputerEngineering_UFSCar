function TraceInfoFlag() {
    this.traceFlag = new Array();
    this.traceFlag["PID.cpp:135c24"]=1;
    this.traceFlag["PID.cpp:135c43"]=1;
    this.traceFlag["PID.cpp:135c50"]=1;
    this.traceFlag["PID.cpp:142c28"]=1;
    this.traceFlag["PID.cpp:142c34"]=1;
    this.traceFlag["PID.cpp:142c55"]=1;
    this.traceFlag["PID.cpp:148c23"]=1;
    this.traceFlag["PID.cpp:148c29"]=1;
    this.traceFlag["PID.cpp:148c56"]=1;
    this.traceFlag["PID.cpp:151c27"]=1;
}
top.TraceInfoFlag.instance = new TraceInfoFlag();
function TraceInfoLineFlag() {
    this.lineTraceFlag = new Array();
    this.lineTraceFlag["PID.cpp:135"]=1;
    this.lineTraceFlag["PID.cpp:142"]=1;
    this.lineTraceFlag["PID.cpp:148"]=1;
    this.lineTraceFlag["PID.cpp:151"]=1;
    this.lineTraceFlag["PID.cpp:183"]=1;
    this.lineTraceFlag["PID.cpp:186"]=1;
    this.lineTraceFlag["PID.cpp:189"]=1;
    this.lineTraceFlag["PID.cpp:226"]=1;
    this.lineTraceFlag["PID.cpp:229"]=1;
    this.lineTraceFlag["PID.cpp:232"]=1;
}
top.TraceInfoLineFlag.instance = new TraceInfoLineFlag();
